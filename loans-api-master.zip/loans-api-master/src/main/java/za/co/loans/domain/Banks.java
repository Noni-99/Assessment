package za.co.loans.domain;

public enum Banks {
    ABSA,
    CAPITEC,
    FNB,
    INVESTEC_LIMITED,
    NEDBANK_LIMITED,
    STANDARD_BANK,
    VBS
}
